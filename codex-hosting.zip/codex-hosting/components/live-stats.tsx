"use client"

import { useEffect, useState } from "react"
import { motion } from "framer-motion"

export function LiveStats() {
  const [stats, setStats] = useState({
    requests: 289432,
    latency: 18,
    uptime: 99.999,
    activeNodes: 342,
  })

  useEffect(() => {
    const interval = setInterval(() => {
      setStats((prev) => ({
        requests: prev.requests + Math.floor(Math.random() * 15),
        latency: 15 + Math.floor(Math.random() * 5),
        uptime: 99.999,
        activeNodes: 340 + Math.floor(Math.random() * 5),
      }))
    }, 2000)
    return () => clearInterval(interval)
  }, [])

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-5xl mx-auto mt-24">
      {[
        { label: "GLOBAL REQUESTS / SEC", value: stats.requests.toLocaleString(), unit: "REQ" },
        { label: "AVG EDGE LATENCY", value: stats.latency, unit: "MS" },
        { label: "NETWORK UPTIME", value: stats.uptime, unit: "%" },
        { label: "ACTIVE EDGE NODES", value: stats.activeNodes, unit: "NODES" },
      ].map((item, i) => (
        <motion.div
          key={item.label}
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: i * 0.1 }}
          className="p-6 rounded-xl border border-white/5 bg-white/5 backdrop-blur-sm"
        >
          <p className="text-[10px] font-mono tracking-widest text-muted-foreground mb-4">{item.label}</p>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-mono font-bold tracking-tighter">{item.value}</span>
            <span className="text-[10px] font-mono text-accent">{item.unit}</span>
          </div>
          <div className="mt-4 h-1 w-full bg-white/5 rounded-full overflow-hidden">
            <motion.div
              className="h-full bg-accent"
              initial={{ width: "0%" }}
              animate={{ width: `${40 + Math.random() * 60}%` }}
              transition={{ duration: 2, repeat: Number.POSITIVE_INFINITY, repeatType: "reverse" }}
            />
          </div>
        </motion.div>
      ))}
    </div>
  )
}
