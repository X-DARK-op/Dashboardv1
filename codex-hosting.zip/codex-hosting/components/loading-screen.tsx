"use client"

import { useState, useEffect } from "react"
import { motion, AnimatePresence } from "framer-motion"
import { CodeXLogo } from "./codex-logo"

export function LoadingScreen() {
  const [isLoading, setIsLoading] = useState(true)
  const [progress, setProgress] = useState(0)

  useEffect(() => {
    // Simulate loading progress
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setTimeout(() => setIsLoading(false), 500)
          return 100
        }
        return prev + Math.random() * 15
      })
    }, 200)

    return () => clearInterval(interval)
  }, [])

  return (
    <AnimatePresence>
      {isLoading && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.5 }}
          className="fixed inset-0 z-[100] bg-background flex flex-col items-center justify-center"
        >
          {/* Animated background grid */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute inset-0" style={{
              backgroundImage: `
                linear-gradient(to right, rgba(255,255,255,0.03) 1px, transparent 1px),
                linear-gradient(to bottom, rgba(255,255,255,0.03) 1px, transparent 1px)
              `,
              backgroundSize: '40px 40px'
            }}>
              <motion.div
                animate={{
                  backgroundPositionY: ['0px', '40px']
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "linear"
                }}
                className="absolute inset-0"
                style={{
                  backgroundImage: `
                    linear-gradient(to right, rgba(255,255,255,0.03) 1px, transparent 1px),
                    linear-gradient(to bottom, rgba(255,255,255,0.03) 1px, transparent 1px)
                  `,
                  backgroundSize: '40px 40px'
                }}
              />
            </div>
          </div>

          {/* Logo and particles */}
          <div className="relative z-10 flex flex-col items-center gap-8">
            <motion.div
              animate={{
                scale: [1, 1.05, 1],
                rotate: [0, 180, 360]
              }}
              transition={{
                duration: 3,
                repeat: Infinity,
                ease: "easeInOut"
              }}
              className="relative"
            >
              <CodeXLogo className="w-24 h-24" />
              
              {/* Orbiting particles */}
              {[...Array(6)].map((_, i) => (
                <motion.div
                  key={i}
                  className="absolute top-1/2 left-1/2 w-2 h-2 rounded-full bg-accent"
                  style={{
                    filter: 'blur(1px)'
                  }}
                  animate={{
                    x: [
                      Math.cos((i * 60 * Math.PI) / 180) * 60,
                      Math.cos(((i * 60 + 360) * Math.PI) / 180) * 60
                    ],
                    y: [
                      Math.sin((i * 60 * Math.PI) / 180) * 60,
                      Math.sin(((i * 60 + 360) * Math.PI) / 180) * 60
                    ]
                  }}
                  transition={{
                    duration: 3,
                    repeat: Infinity,
                    ease: "linear"
                  }}
                />
              ))}
            </motion.div>

            {/* Loading text */}
            <div className="flex flex-col items-center gap-4 min-w-[300px]">
              <motion.h2
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-2xl font-bold tracking-tight font-mono"
              >
                CodeXHosting
              </motion.h2>
              
              {/* Progress bar */}
              <div className="w-full h-1 bg-white/5 rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-gradient-to-r from-accent to-blue-500"
                  style={{
                    width: `${progress}%`
                  }}
                  transition={{ duration: 0.3 }}
                />
              </div>
              
              {/* Status text */}
              <motion.p
                className="text-sm text-muted-foreground font-mono"
                animate={{
                  opacity: [0.5, 1, 0.5]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity
                }}
              >
                {progress < 30 && "Initializing infrastructure..."}
                {progress >= 30 && progress < 60 && "Connecting to edge network..."}
                {progress >= 60 && progress < 90 && "Loading resources..."}
                {progress >= 90 && "Ready!"}
              </motion.p>
            </div>
          </div>

          {/* Corner decorations */}
          <div className="absolute top-4 left-4 w-12 h-12 border-l-2 border-t-2 border-accent/30" />
          <div className="absolute top-4 right-4 w-12 h-12 border-r-2 border-t-2 border-accent/30" />
          <div className="absolute bottom-4 left-4 w-12 h-12 border-l-2 border-b-2 border-accent/30" />
          <div className="absolute bottom-4 right-4 w-12 h-12 border-r-2 border-b-2 border-accent/30" />
        </motion.div>
      )}
    </AnimatePresence>
  )
}
