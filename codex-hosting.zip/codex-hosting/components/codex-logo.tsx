"use client"

import { motion } from "framer-motion"

export function CodeXLogo({ className = "w-10 h-10" }: { className?: string }) {
  return (
    <motion.svg
      viewBox="0 0 100 100"
      className={className}
      initial={{ opacity: 0, scale: 0.8 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.5 }}
    >
      <defs>
        <linearGradient id="logo-gradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="oklch(0.75 0.22 240)" />
          <stop offset="100%" stopColor="oklch(0.55 0.18 240)" />
        </linearGradient>
        <filter id="glow">
          <feGaussianBlur stdDeviation="2" result="coloredBlur" />
          <feMerge>
            <feMergeNode in="coloredBlur" />
            <feMergeNode in="SourceGraphic" />
          </feMerge>
        </filter>
      </defs>
      
      {/* Outer hexagon */}
      <motion.path
        d="M 50 5 L 85 27.5 L 85 72.5 L 50 95 L 15 72.5 L 15 27.5 Z"
        fill="none"
        stroke="url(#logo-gradient)"
        strokeWidth="2"
        filter="url(#glow)"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ duration: 1.5, ease: "easeInOut" }}
      />
      
      {/* Inner C shape */}
      <motion.path
        d="M 65 35 A 20 20 0 0 1 65 65 L 55 65 A 10 10 0 0 0 55 35 Z"
        fill="url(#logo-gradient)"
        initial={{ scale: 0, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.5, duration: 0.8 }}
      />
      
      {/* X cross lines */}
      <motion.line
        x1="30"
        y1="35"
        x2="45"
        y2="65"
        stroke="url(#logo-gradient)"
        strokeWidth="3"
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
      />
      <motion.line
        x1="45"
        y1="35"
        x2="30"
        y2="65"
        stroke="url(#logo-gradient)"
        strokeWidth="3"
        strokeLinecap="round"
        initial={{ pathLength: 0, opacity: 0 }}
        animate={{ pathLength: 1, opacity: 1 }}
        transition={{ delay: 0.8, duration: 0.5 }}
      />
    </motion.svg>
  )
}
