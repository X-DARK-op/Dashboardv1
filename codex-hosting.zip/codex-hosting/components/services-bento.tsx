"use client"

import { motion } from "framer-motion"
import { Bot, Gamepad2, Server, Globe, Zap, Shield, Cpu, HardDrive } from "lucide-react"
import { Card3DIcon } from "./3d-card-icon"
import Image from "next/image"

const services = [
  {
    title: "Discord Bot Hosting",
    description: "Deploy your Discord bots with 99.99% uptime and instant scaling",
    icon: Bot,
    shape: "box" as const,
    features: ["24/7 Uptime", "Auto-Restart", "Custom Domains", "Real-time Logs"],
    highlight: "Starting at $2.99/mo",
    bgGradient: "from-blue-500/10 to-cyan-500/10",
    image: "/futuristic-discord-bot-dashboard-with-chat-interfa.jpg",
  },
  {
    title: "Minecraft Server Hosting",
    description: "High-performance Minecraft servers with DDoS protection and mod support",
    icon: Gamepad2,
    shape: "sphere" as const,
    features: ["1-Click Modpacks", "Automatic Backups", "DDoS Protection", "Full FTP Access"],
    highlight: "Starting at $5.99/mo",
    bgGradient: "from-green-500/10 to-emerald-500/10",
    image: "/minecraft-server-control-panel-with-blocks.jpg",
  },
  {
    title: "VPS Hosting",
    description: "Enterprise-grade virtual private servers with full root access and SSD storage",
    icon: Server,
    shape: "cone" as const,
    features: ["Full Root Access", "SSD Storage", "99.9% Uptime SLA", "24/7 Support"],
    highlight: "Starting at $8.99/mo",
    bgGradient: "from-purple-500/10 to-pink-500/10",
    image: "/modern-server-rack-data-center-infrastructure.jpg",
  },
  {
    title: "Domain Registration",
    description: "Secure your perfect domain with free SSL and DNS management",
    icon: Globe,
    shape: "torus" as const,
    features: ["Free SSL Certificates", "DNS Management", "WHOIS Privacy", "Easy Transfer"],
    highlight: "Starting at $9.99/yr",
    bgGradient: "from-orange-500/10 to-red-500/10",
    image: "/global-network-map-with-domains-and-connections.jpg",
  },
]

const techSpecs = [
  { icon: Zap, label: "Edge Network", value: "300+ Locations" },
  { icon: Shield, label: "DDoS Protection", value: "Enterprise-Grade" },
  { icon: Cpu, label: "CPU Performance", value: "AMD EPYC / Intel Xeon" },
  { icon: HardDrive, label: "Storage", value: "NVMe SSD" },
]

export function ServicesBento() {
  return (
    <section id="services" className="py-32 relative">
      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-b from-white to-white/60 bg-clip-text text-transparent">
            Powerful Hosting Solutions
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            From Discord bots to enterprise VPS, we provide infrastructure for every use case
          </p>
        </motion.div>

        {/* Bento Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-12">
          {services.map((service, index) => (
            <motion.div
              key={service.title}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className={`glass-card rounded-2xl overflow-hidden group hover:glow-accent-sm transition-all duration-500 bg-gradient-to-br ${service.bgGradient}`}
            >
              <div className="relative h-48 overflow-hidden">
                <Image
                  src={service.image || "/placeholder.svg"}
                  alt={service.title}
                  fill
                  className="object-cover opacity-50 group-hover:opacity-70 group-hover:scale-105 transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
              </div>

              <div className="p-8">
                {/* 3D Icon */}
                <div className="mb-6 -mt-20 relative z-10">
                  <Card3DIcon type={service.shape} />
                </div>

                {/* Content */}
                <div className="flex items-start gap-4 mb-6">
                  <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center group-hover:scale-110 transition-transform">
                    <service.icon className="w-6 h-6 text-accent" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-2">{service.title}</h3>
                    <p className="text-muted-foreground leading-relaxed">{service.description}</p>
                  </div>
                </div>

                {/* Features Grid */}
                <div className="grid grid-cols-2 gap-3 mb-6">
                  {service.features.map((feature) => (
                    <div
                      key={feature}
                      className="flex items-center gap-2 text-sm bg-white/5 rounded-lg px-3 py-2 border border-white/5"
                    >
                      <div className="w-1.5 h-1.5 rounded-full bg-accent"></div>
                      <span className="text-foreground/90">{feature}</span>
                    </div>
                  ))}
                </div>

                {/* Highlight */}
                <div className="pt-4 border-t border-white/10">
                  <p className="text-accent font-mono font-semibold">{service.highlight}</p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Tech Specs Bar */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="glass-card rounded-2xl p-8"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {techSpecs.map((spec, index) => (
              <motion.div
                key={spec.label}
                initial={{ opacity: 0, scale: 0.9 }}
                whileInView={{ opacity: 1, scale: 1 }}
                viewport={{ once: true }}
                transition={{ delay: index * 0.1 }}
                className="text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-accent/10 flex items-center justify-center mx-auto mb-4">
                  <spec.icon className="w-6 h-6 text-accent" />
                </div>
                <p className="text-xs font-mono tracking-widest text-muted-foreground mb-2">{spec.label}</p>
                <p className="text-sm font-semibold">{spec.value}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  )
}
