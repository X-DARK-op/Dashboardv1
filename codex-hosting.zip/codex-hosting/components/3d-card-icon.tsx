"use client"

import { Canvas } from "@react-three/fiber"
import { Float, Box, Sphere, Cone, Torus } from "@react-three/drei"
import { useRef } from "react"
import { useFrame } from "@react-three/fiber"
import type { Mesh } from "three"

interface IconMeshProps {
  type: "box" | "sphere" | "cone" | "torus"
}

function IconMesh({ type }: IconMeshProps) {
  const meshRef = useRef<Mesh>(null)

  useFrame((state) => {
    if (meshRef.current) {
      meshRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.5) * 0.2
      meshRef.current.rotation.y += 0.01
    }
  })

  const colors = {
    box: "#0ea5e9",
    sphere: "#3b82f6",
    cone: "#06b6d4",
    torus: "#0284c7",
  }

  return (
    <Float speed={2} rotationIntensity={0.5} floatIntensity={0.5}>
      {type === "box" && (
        <Box ref={meshRef} args={[1.2, 1.2, 1.2]}>
          <meshStandardMaterial color={colors.box} metalness={0.8} roughness={0.2} />
        </Box>
      )}
      {type === "sphere" && (
        <Sphere ref={meshRef} args={[0.7, 32, 32]}>
          <meshStandardMaterial color={colors.sphere} metalness={0.9} roughness={0.1} />
        </Sphere>
      )}
      {type === "cone" && (
        <Cone ref={meshRef} args={[0.6, 1.2, 32]}>
          <meshStandardMaterial color={colors.cone} metalness={0.7} roughness={0.3} />
        </Cone>
      )}
      {type === "torus" && (
        <Torus ref={meshRef} args={[0.6, 0.2, 16, 100]}>
          <meshStandardMaterial color={colors.torus} metalness={0.85} roughness={0.15} />
        </Torus>
      )}
      <ambientLight intensity={0.5} />
      <directionalLight position={[5, 5, 5]} intensity={1} />
      <pointLight position={[-5, -5, -5]} intensity={0.5} color={colors[type]} />
    </Float>
  )
}

interface Card3DIconProps {
  type: "box" | "sphere" | "cone" | "torus"
}

export function Card3DIcon({ type }: Card3DIconProps) {
  return (
    <div className="w-full h-40 relative">
      <Canvas camera={{ position: [0, 0, 3], fov: 50 }}>
        <IconMesh type={type} />
      </Canvas>
    </div>
  )
}
