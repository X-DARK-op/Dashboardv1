"use client"

import Link from "next/link"
import { Button } from "@/components/ui/button"
import { motion } from "framer-motion"
import { CodeXLogo } from "./codex-logo"

export function Navbar() {
  return (
    <motion.nav 
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      className="fixed top-0 w-full z-50 border-b border-white/5 bg-background/80 backdrop-blur-md"
    >
      <div className="container mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="group-hover:scale-110 transition-transform">
              <CodeXLogo className="w-8 h-8" />
            </div>
            <span className="font-bold text-xl tracking-tight">CodeXHosting</span>
          </Link>
          <div className="hidden md:flex items-center gap-6 text-sm font-medium text-muted-foreground">
            <Link href="#services" className="hover:text-foreground transition-colors">
              Services
            </Link>
            <Link href="#pricing" className="hover:text-foreground transition-colors">
              Pricing
            </Link>
            <Link href="#features" className="hover:text-foreground transition-colors">
              Infrastructure
            </Link>
            <Link href="#" className="hover:text-foreground transition-colors">
              Docs
            </Link>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <Button variant="default" className="bg-accent hover:bg-accent/90 text-white rounded-full px-6 glow-accent-sm">
            Get Started
          </Button>
        </div>
      </div>
    </motion.nav>
  )
}
