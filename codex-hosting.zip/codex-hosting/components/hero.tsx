"use client"
import { motion } from "framer-motion"
import { LiveStats } from "./live-stats"
import { Hero3DScene } from "./3d-hero-scene"
import { Suspense } from "react"

export function Hero() {
  return (
    <section className="relative pt-32 pb-20 md:pt-48 md:pb-32 overflow-hidden">
      <Suspense fallback={null}>
        <Hero3DScene />
      </Suspense>

      <div className="container mx-auto px-4 relative z-10 text-center">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-xs font-medium text-muted-foreground mb-8"
        >
          <span className="relative flex h-2 w-2">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-accent opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2 w-2 bg-accent"></span>
          </span>
          Next-Gen Infrastructure Now Live
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.1 }}
          className="text-5xl md:text-8xl font-bold tracking-tighter mb-6 bg-gradient-to-b from-white to-white/40 bg-clip-text text-transparent"
        >
          The Future of <br /> Cloud Hosting
        </motion.h1>

        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="max-w-2xl mx-auto text-lg md:text-xl text-muted-foreground mb-10 text-balance"
        >
          CodeXHosting provides high-performance infrastructure for teams building the next generation of web
          applications. Deploy globally in seconds.
        </motion.p>

        <LiveStats />

        {/* Mock Code Block */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="max-w-4xl mx-auto rounded-xl border border-white/10 bg-black/50 backdrop-blur-xl overflow-hidden shadow-2xl text-left mt-24"
        >
          <div className="flex items-center gap-2 px-4 py-3 border-b border-white/10 bg-white/5">
            <div className="flex gap-1.5">
              <div className="w-3 h-3 rounded-full bg-red-500/50"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500/50"></div>
              <div className="w-3 h-3 rounded-full bg-green-500/50"></div>
            </div>
            <span className="text-xs text-muted-foreground ml-2 font-mono">codex-deploy.sh</span>
          </div>
          <div className="p-6 font-mono text-sm leading-relaxed overflow-x-auto">
            <div className="flex gap-4">
              <span className="text-white/20 select-none">1</span>
              <span>
                <span className="text-accent">$</span> npm install -g codex-cli
              </span>
            </div>
            <div className="flex gap-4">
              <span className="text-white/20 select-none">2</span>
              <span>
                <span className="text-accent">$</span> codex login
              </span>
            </div>
            <div className="flex gap-4">
              <span className="text-white/20 select-none">3</span>
              <span className="text-muted-foreground"># Initializing infrastructure...</span>
            </div>
            <div className="flex gap-4">
              <span className="text-white/20 select-none">4</span>
              <span>
                <span className="text-accent">$</span> codex deploy{" "}
                <span className="text-white/60">--region global</span>
              </span>
            </div>
            <div className="flex gap-4 mt-2">
              <span className="text-white/20 select-none">5</span>
              <span className="text-green-400">✓ Deployment successful!</span>
            </div>
            <div className="flex gap-4">
              <span className="text-white/20 select-none">6</span>
              <span className="text-white/60">URL: https://app.codexhosting.com</span>
            </div>
          </div>
        </motion.div>
      </div>

      {/* Background Gradients */}
      <div className="absolute top-0 left-1/2 -translate-x-1/2 w-[1000px] h-[600px] bg-accent/5 blur-[120px] rounded-full pointer-events-none"></div>
    </section>
  )
}
