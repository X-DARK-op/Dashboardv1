"use client"

import { Canvas } from "@react-three/fiber"
import { OrbitControls, Float, Sphere, MeshDistortMaterial, Environment } from "@react-three/drei"

function FloatingElements() {
  return (
    <>
      <Float speed={1.5} rotationIntensity={0.5} floatIntensity={0.5}>
        <Sphere args={[1, 64, 64]} position={[-3, 1, -2]}>
          <MeshDistortMaterial
            color="#0ea5e9"
            attach="material"
            distort={0.4}
            speed={2}
            roughness={0.2}
            metalness={0.8}
          />
        </Sphere>
      </Float>

      <Float speed={2} rotationIntensity={0.8} floatIntensity={0.8}>
        <Sphere args={[0.7, 64, 64]} position={[3, -1, -1]}>
          <MeshDistortMaterial
            color="#3b82f6"
            attach="material"
            distort={0.5}
            speed={3}
            roughness={0.1}
            metalness={0.9}
          />
        </Sphere>
      </Float>

      <Float speed={1.2} rotationIntensity={0.3} floatIntensity={0.6}>
        <Sphere args={[0.5, 64, 64]} position={[0, 2, -3]}>
          <MeshDistortMaterial
            color="#06b6d4"
            attach="material"
            distort={0.3}
            speed={1.5}
            roughness={0.3}
            metalness={0.7}
          />
        </Sphere>
      </Float>

      <ambientLight intensity={0.5} />
      <directionalLight position={[10, 10, 5]} intensity={1} />
      <pointLight position={[-10, -10, -5]} intensity={0.5} color="#0ea5e9" />
      <Environment preset="night" />
    </>
  )
}

export function Floating3DBg() {
  return (
    <div className="fixed inset-0 pointer-events-none opacity-30 z-0">
      <Canvas camera={{ position: [0, 0, 8], fov: 50 }}>
        <FloatingElements />
        <OrbitControls enableZoom={false} enablePan={false} autoRotate autoRotateSpeed={0.5} />
      </Canvas>
    </div>
  )
}
