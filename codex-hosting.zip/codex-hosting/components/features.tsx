"use client"

import { motion } from "framer-motion"
import { Zap, Shield, BarChart3, Cloud, Cpu, Globe } from "lucide-react"
import Image from "next/image"

const features = [
  {
    title: "Global Edge Network",
    description: "Deploy your code to over 300 locations worldwide for minimal latency and maximum speed.",
    icon: Globe,
    image: "/world-map-with-glowing-network-nodes.jpg",
  },
  {
    title: "DDoS Protection",
    description: "Enterprise-grade security included by default to keep your infrastructure safe from attacks.",
    icon: Shield,
    image: "/digital-security-shield.png",
  },
  {
    title: "Auto-Scaling",
    description:
      "Our infrastructure scales automatically with your traffic, so you never have to worry about downtime.",
    icon: Zap,
    image: "/ascending-graph-with-server-icons-scaling-up.jpg",
  },
  {
    title: "Real-time Analytics",
    description: "Deep insights into your performance, traffic patterns, and error logs in real-time.",
    icon: BarChart3,
    image: "/modern-analytics-dashboard.png",
  },
  {
    title: "Managed Databases",
    description: "Seamlessly integrate with PostgreSQL, Redis, and more with one-click provisioning.",
    icon: Cloud,
    image: "/cloud-database-servers-connected.jpg",
  },
  {
    title: "Custom Hardware",
    description: "Optional dedicated bare-metal instances for high-compute workloads and processing.",
    icon: Cpu,
    image: "/modern-server-cpu-and-hardware-components.jpg",
  },
]

export function Features() {
  return (
    <section id="features" className="py-24 border-t border-white/5 relative">
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-16"
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Enterprise Infrastructure</h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            Built on cutting-edge technology to deliver unmatched performance and reliability
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <motion.div
              key={index}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.1 }}
              className="group rounded-2xl border border-white/5 bg-white/[0.02] hover:bg-white/[0.04] overflow-hidden transition-all"
            >
              <div className="relative h-40 overflow-hidden">
                <Image
                  src={feature.image || "/placeholder.svg"}
                  alt={feature.title}
                  fill
                  className="object-cover opacity-40 group-hover:opacity-60 group-hover:scale-105 transition-all duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-b from-transparent to-background" />
              </div>

              <div className="p-8">
                <div className="w-12 h-12 rounded-lg bg-white/5 flex items-center justify-center mb-6 group-hover:scale-110 transition-transform -mt-16 relative z-10 backdrop-blur-sm border border-white/10">
                  <feature.icon className="w-6 h-6 text-accent" />
                </div>
                <h3 className="text-xl font-bold mb-3">{feature.title}</h3>
                <p className="text-muted-foreground leading-relaxed">{feature.description}</p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
