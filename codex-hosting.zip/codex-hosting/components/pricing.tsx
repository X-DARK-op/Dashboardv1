"use client"

import { motion } from "framer-motion"
import { Check, Sparkles } from "lucide-react"
import { Button } from "@/components/ui/button"

const pricingPlans = [
  {
    name: "Starter Bot",
    description: "Perfect for small Discord communities",
    price: "2.99",
    period: "month",
    category: "Discord Bot Hosting",
    featured: false,
    features: ["1 Bot Instance", "512MB RAM", "5GB Storage", "24/7 Uptime", "Auto-Restart", "Basic Support"],
  },
  {
    name: "Pro Bot",
    description: "For growing servers with multiple bots",
    price: "7.99",
    period: "month",
    category: "Discord Bot Hosting",
    featured: true,
    features: [
      "3 Bot Instances",
      "2GB RAM",
      "20GB Storage",
      "99.99% Uptime SLA",
      "Priority Support",
      "Custom Domains",
      "Real-time Monitoring",
    ],
  },
  {
    name: "Minecraft - Basic",
    description: "Great for vanilla servers",
    price: "5.99",
    period: "month",
    category: "Minecraft Hosting",
    featured: false,
    features: ["2GB RAM", "Unlimited Slots", "DDoS Protection", "Automatic Backups", "FTP Access", "Plugin Support"],
  },
  {
    name: "Minecraft - Premium",
    description: "For modded and high-player servers",
    price: "14.99",
    period: "month",
    category: "Minecraft Hosting",
    featured: true,
    features: [
      "8GB RAM",
      "Unlimited Slots",
      "DDoS Protection",
      "1-Click Modpacks",
      "Daily Backups",
      "Full FTP & MySQL",
      "Priority Support",
      "Custom JAR Support",
    ],
  },
  {
    name: "VPS - Cloud",
    description: "Flexible virtual server",
    price: "8.99",
    period: "month",
    category: "VPS Hosting",
    featured: false,
    features: [
      "2 vCPU Cores",
      "4GB RAM",
      "80GB NVMe SSD",
      "Full Root Access",
      "Ubuntu/Debian/CentOS",
      "99.9% Uptime SLA",
    ],
  },
  {
    name: "VPS - Enterprise",
    description: "Maximum performance and control",
    price: "24.99",
    period: "month",
    category: "VPS Hosting",
    featured: true,
    features: [
      "8 vCPU Cores",
      "16GB RAM",
      "320GB NVMe SSD",
      "Full Root Access",
      "All OS Options",
      "Dedicated IPv4",
      "Priority Support",
      "Advanced Monitoring",
    ],
  },
]

export function Pricing() {
  return (
    <section id="pricing" className="py-32 relative">
      <div className="container mx-auto px-4 relative z-10">
        {/* Section Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="text-center mb-20"
        >
          <h2 className="text-4xl md:text-6xl font-bold mb-6 bg-gradient-to-b from-white to-white/60 bg-clip-text text-transparent">
            Transparent Pricing
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
            No hidden fees. No surprises. Just reliable infrastructure at predictable prices.
          </p>
        </motion.div>

        {/* Pricing Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {pricingPlans.map((plan, index) => (
            <motion.div
              key={plan.name}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: index * 0.05 }}
              className={`relative glass-card rounded-2xl p-8 ${
                plan.featured ? "border-accent/50 glow-accent-sm scale-105 lg:scale-110" : "hover:border-white/20"
              } transition-all duration-500`}
            >
              {/* Featured Badge */}
              {plan.featured && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-accent rounded-full text-xs font-mono font-semibold flex items-center gap-1.5">
                  <Sparkles className="w-3 h-3" />
                  MOST POPULAR
                </div>
              )}

              {/* Category Tag */}
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/5 border border-white/10 text-xs font-mono text-muted-foreground mb-6">
                {plan.category}
              </div>

              {/* Plan Info */}
              <h3 className="text-2xl font-bold mb-2">{plan.name}</h3>
              <p className="text-sm text-muted-foreground mb-6">{plan.description}</p>

              {/* Price */}
              <div className="mb-8">
                <div className="flex items-baseline gap-1">
                  <span className="text-5xl font-bold font-mono">${plan.price}</span>
                  <span className="text-muted-foreground text-sm">/{plan.period}</span>
                </div>
              </div>

              {/* CTA Button */}
              <Button
                className={`w-full mb-8 ${
                  plan.featured
                    ? "bg-accent hover:bg-accent/90 text-accent-foreground"
                    : "bg-white/5 hover:bg-white/10 text-foreground border border-white/10"
                }`}
              >
                Get Started
              </Button>

              {/* Features List */}
              <ul className="space-y-3">
                {plan.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-3 text-sm">
                    <Check className="w-4 h-4 text-accent mt-0.5 flex-shrink-0" />
                    <span className="text-foreground/90">{feature}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Domain Pricing Note */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          className="mt-12 text-center glass-card rounded-2xl p-8"
        >
          <h3 className="text-xl font-bold mb-4 flex items-center justify-center gap-2">
            <Globe className="w-5 h-5 text-accent" />
            Domain Registration
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {[
              { ext: ".com", price: "9.99" },
              { ext: ".net", price: "11.99" },
              { ext: ".org", price: "12.99" },
              { ext: ".dev", price: "14.99" },
            ].map((domain) => (
              <div key={domain.ext} className="text-center">
                <p className="text-2xl font-bold font-mono mb-1">{domain.ext}</p>
                <p className="text-accent font-mono">${domain.price}/year</p>
              </div>
            ))}
          </div>
          <p className="text-xs text-muted-foreground mt-6">
            Includes free SSL certificate, DNS management, and WHOIS privacy protection
          </p>
        </motion.div>
      </div>
    </section>
  )
}

function Globe({ className }: { className?: string }) {
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className={className}
    >
      <circle cx="12" cy="12" r="10" />
      <path d="M12 2a14.5 14.5 0 0 0 0 20 14.5 14.5 0 0 0 0-20" />
      <path d="M2 12h20" />
    </svg>
  )
}
