import type React from "react"
import type { Metadata } from "next"
import { Geist, Geist_Mono } from "next/font/google"
import { Analytics } from "@vercel/analytics/next"
import "./globals.css"
import { LoadingScreen } from "@/components/loading-screen"

const geistSans = Geist({
  subsets: ["latin"],
  variable: "--font-sans",
})

const geistMono = Geist_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
})

// Updated metadata for CodeXHosting
export const metadata: Metadata = {
  title: "CodeXHosting - Next-Gen Cloud Infrastructure",
  description:
    "High-performance hosting solutions for Discord bots, Minecraft servers, VPS, and domains. Deploy globally in seconds with enterprise-grade infrastructure.",
  generator: "ryuzaki",
  keywords: ["cloud hosting", "vps", "minecraft hosting", "discord bot hosting", "domain registration"],
  icons: {
    icon: [
      {
        url: "/icon.svg",
        type: "image/svg+xml",
      },
    ],
    apple: "/icon.svg",
  },
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en">
      <body className={`${geistSans.variable} ${geistMono.variable} font-sans antialiased`}>
        <LoadingScreen />
        {children}
        <Analytics />
      </body>
    </html>
  )
}
